
int main(){


	while(1);
}
