# The xPack QEMU Arm

**The xPack QEMU Arm** (formerly GNU MCU Eclipse QEMU)
is the **xPack** version of **QEMU**,
an open source project.

For more details, please read the corresponding release pages:

- https://xpack.github.io/qemu-arm/releases/
- http://www.qemu.org

Thank you for using open source software,

Liviu Ionescu
